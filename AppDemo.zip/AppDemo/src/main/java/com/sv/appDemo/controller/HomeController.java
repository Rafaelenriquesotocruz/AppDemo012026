package com.sv.appDemo.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.LinkedList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.sv.appDemo.model.Trip;



@Controller
public class HomeController {

	@GetMapping("/")
	public String mostrarhome (Model model) {
	
		model.addAttribute("mensaje1", "¡Bienvenido a AppTrip!");

		
		return "home";
}

	@GetMapping("/listado")
	public String mostrarListado(Model model) {
		
	    
	    List<String> lista = new ArrayList<>();
	    lista.add("En la Montaña");
	    lista.add("En la Ciudad");
	    lista.add("En los pueblos");
	    lista.add("En las playas");
	    

	    model.addAttribute("listadoTrips", lista);
	    return "listado";
	}
	
	
	@GetMapping("/detalle")
	public String mostrarDetalle(Model model) {
	    Trip trip = new Trip();
	    trip.setId(1L); 
	    trip.setNombre("Rapel en Volcatenango");
	    trip.setDescripcion("Aventura rapel en un circuito conectado en las...");
	    trip.setFecha(new Date());
	    trip.setCosto(10.0);
	    trip.setDestacado(1);

	    
	    model.addAttribute("trip", trip);
	    return "detalle";
	}
    
    public List<Trip> getTrip() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        List<Trip> lista = new LinkedList<Trip>();
        
        try {
            Trip trip1 = new Trip();
            trip1.setId(1L);
            trip1.setNombre("Rapel en Volcatenando");
            trip1.setDescripcion("Hacer rapel en los circuitos de Volcatenango");
            trip1.setFecha(sdf.parse("10-05-2022"));
            trip1.setCosto(5.0);
            trip1.setDestacado(1);
    	    trip1.setImagen("trip1.jpg");

            Trip trip2 = new Trip();
            trip2.setId(2L);
            trip2.setNombre("Deslizadero en El picnic");
            trip2.setDescripcion("Deslizarte en un divertido tovagon sobre la colina");
            trip2.setFecha(sdf.parse("10-05-2022"));
            trip2.setCosto(5.0);
            trip2.setDestacado(1);
    	    trip2.setImagen("trip2.jpg");

            Trip trip3 = new Trip();
            trip3.setId(3L);
            trip3.setNombre("Comida y Flores");
            trip3.setDescripcion("Disfrutar de un amplio jardín el cual podras comprar");
            trip3.setFecha(sdf.parse("10-05-2022"));
            trip3.setCosto(1.0);
            trip3.setDestacado(0);
    	    trip3.setImagen("trip3.jpg");

            Trip trip4 = new Trip();
            trip4.setId(4L);
            trip4.setNombre("Caminatas");
            trip4.setDescripcion("Disfruta hacer senderismo por las montañas chaletacas");
            trip4.setFecha(sdf.parse("01-02-2022"));
            trip4.setCosto(10.0);
            trip4.setDestacado(1);
    	    trip4.setImagen("trip4.jpg");

            lista.add(trip1);
            lista.add(trip2);
            lista.add(trip3);
            lista.add(trip4);

        } catch (ParseException e) {
            System.out.println("Error al parsear fecha: " + e.getMessage());
        }
        
        return lista;
    }
    
    @GetMapping("/tabla")
    public String mostrarTabla(Model model) {
        List<Trip> viajes = getTrip();
        model.addAttribute("trips", viajes);
        return "tabla";
    }
} 
