package com.sv.appDemo.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sv.appDemo.model.Trip;

@Controller
@RequestMapping("/trips")
public class TripController {


    private List<Trip> getTrip() {
        return new HomeController().getTrip();
    }


    @GetMapping("/view/{id}")
    public String verDetalle(@PathVariable("id") int idTrip, Model model) {
        
        System.out.println("ID del viaje (view): " + idTrip);

        List<Trip> viajes = getTrip();
        Trip tripEncontrado = null;

        for (Trip t : viajes) {
            if (t.getId() == idTrip) {
                tripEncontrado = t;
                break;
            }
        }

        if (tripEncontrado != null) {
            model.addAttribute("trip", tripEncontrado);
        } else {
            return "redirect:/tabla";
        }

        return "trips/detalle";
    }


    @GetMapping("/delete")
    public String eliminarTrip(@RequestParam("id") int idTrip, Model model) {
        
        System.out.println("ID a eliminar: " + idTrip);

        
        model.addAttribute("id", idTrip);
        return "mensaje";  
    }
}