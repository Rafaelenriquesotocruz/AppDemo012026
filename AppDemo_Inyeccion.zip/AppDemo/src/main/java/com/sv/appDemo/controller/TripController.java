package com.sv.appDemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sv.appDemo.model.Trip;
import com.sv.appDemo.service.ITripService;

@Controller
@RequestMapping("/trips")
public class TripController {

    @Autowired
    private ITripService tripService;


    @GetMapping("/view/{id}")
    public String verDetalle(@PathVariable("id") Long idTrip, Model model) {
        
        System.out.println("ID del viaje (view): " + idTrip);

        Trip trip = tripService.buscarPorId(idTrip);

        if (trip != null) {
            model.addAttribute("trip", trip);
        } else {
            return "redirect:/tabla";
        }

        return "trips/detalle";
    }


    @GetMapping("/delete")
    public String eliminarTrip(@RequestParam("id") Long idTrip, Model model) {
        
        System.out.println("ID a eliminar: " + idTrip);
        
        model.addAttribute("id", idTrip);
        return "mensaje";
    }
}