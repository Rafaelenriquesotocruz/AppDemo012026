package com.sv.appDemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/categorias")
public class CategoriasTripController {


    @GetMapping("/index")
    public String mostrarIndex(Model model) {

        return "categoriasTrip/listCategoria";
    }


    @GetMapping("/create")
    public String crear() {
        return "categoriasTrip/formCategoria";
    }


    @PostMapping("/save")
    public String guardarCategoria(@RequestParam("nombre") String nombreCategoria, Model model) {
        

        System.out.println("📌 Categoría a guardar: " + nombreCategoria);
        

        
        model.addAttribute("mensaje", "Categoría '" + nombreCategoria + "' guardada correctamente");
        
        return "mensaje";  
    }
}