package com.sv.appDemo.model;

import java.util.Date;

public class Trip {

    private Long id;
    private String nombre;
    private String descripcion;
    private Date fecha;
    private double costo;
    private int destacado;
    private String imagen = "no-image.png";
    
    public Trip() {
    }
    
    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getDescripcion() {
        return descripcion;
    }
    
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    
    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }
    
    public int getDestacado() {
        return destacado;
    }

    public void setDestacado(int destacado) { 
        this.destacado = destacado;
    }
    
    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }


    @Override
    public String toString() {
        return "Trip{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", fecha=" + fecha +
                ", costo=" + costo +
                ", destacado=" + destacado +
                ", imagen='" + imagen + '\'' +   // ← AGREGADO
                '}';
    }
}
