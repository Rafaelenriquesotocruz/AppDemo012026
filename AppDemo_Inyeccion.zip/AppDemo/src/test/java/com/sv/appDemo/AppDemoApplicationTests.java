package com.sv.appDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
